# Snake in Javascript

![alt text](coding_snake_cover.png)

YouTube Link: https://youtu.be/7Azlj0f9vas

Try it:
https://codingwith-adam.github.io/snake/
